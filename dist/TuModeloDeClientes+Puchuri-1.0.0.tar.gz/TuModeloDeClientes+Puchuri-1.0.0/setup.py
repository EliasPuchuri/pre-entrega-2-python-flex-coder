from setuptools import setup

setup(
  name = 'TuModeloDeClientes+Puchuri',
  version = '1.0.0',
  description = 'Paquete distribuido',
  author = 'Daniel Puchuri',
  author_email= "eliaspuchuri1105@gmail.com",
  packages = ["paquete1"]
)
